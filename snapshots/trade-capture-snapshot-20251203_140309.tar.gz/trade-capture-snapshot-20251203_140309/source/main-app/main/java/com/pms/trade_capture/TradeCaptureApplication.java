package com.pms.trade_capture;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TradeCaptureApplication {

	public static void main(String[] args) {
		SpringApplication.run(TradeCaptureApplication.class, args);
	}

}
