#!/bin/bash
# Enable RabbitMQ Stream plugin on startup
rabbitmq-plugins enable rabbitmq_stream